import SwiftUI

struct VencedorView: View {
    
    var vencedor: String
    
    var restartAction: () -> Void
    
    var body: some View {
        VStack {
            Spacer()
            Text("Nicee! Vencedor")
            Spacer()
            Text(vencedor)
                .font(Font.system(size: 90))
            Spacer()
            Button("Reiniciar") { 
                restartAction()
            }
            .padding()
            .background(Color.white)
            .cornerRadius(15.0)
            Spacer()
        }
    }
}

struct VencedorView_Previews: PreviewProvider {
    static var previews: some View {
        VencedorView(vencedor: "Taylor"){}
            .background(Color.pink)
            .ignoresSafeArea()
    }
}
